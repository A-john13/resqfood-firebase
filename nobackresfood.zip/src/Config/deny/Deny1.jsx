import "./deny.css";
import React, { useState,useEffect } from "react";
import useFirebaseCRUD from "../../Config/firebaseCRUD";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import FloatingLabel from "react-bootstrap/FloatingLabel";
import { useNavigate } from "react-router-dom";
import { useFirebase } from "../../Config/firebase";

const Deny1 = () => {
  const { UID, userRole } = useFirebase();
 
  return (
    <div style={{background:"grey"}}>
        zbvz
    </div>
  );
};

export default Deny1;
