import React from "react";
import { Container, Row, Col, Carousel, Button } from "react-bootstrap";
import { FaChevronLeft, FaChevronRight } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import { LandingCarousel } from "../Reusable/Carousel";
import NavBar from "../Reusable/Nav";
import "./CSS/LandingPage.css";

const LandingPage = () => {
  const nav = useNavigate();

  return (
    <Container fluid className="m-0 p-0 text-center landing-page">
      <> <NavBar></NavBar>
      </>
      <Container className="m-0 p-5 content">
        <Row>
          <Col>
            <h1 className="title text-pop-up-top">ResQFood</h1>
            
            <h1 className="subheadings1 tracking-in-expand">Feeding Hope,Together</h1>
            <h5 className="subheadings">
              Discover surplus food,Feed those in need. Join us in making a
              difference, one meal at a time.
            </h5>
            <p className="p">
              Stop Food Waste, Start Saving Lives. Learn about the impact of
              food wastage and how you can make a difference.
            </p>
             
        <Row className="butons ">
          <Button
            className="mx-3 getStarted tracking-in-expand"
            style={{ width: "40%" }}
            onClick={() => nav("/login")}>
            Get Started
          </Button>

          <Button
            className="xm-3 getStarted tracking-in-expand"
            style={{ width: "40%" }}
            onClick={() => nav("/")}>
            Learn More
          </Button>
        </Row>

          </Col>
        </Row>
        <Row>
          <Col>
            <h2 className="subheadings">Why It Matters</h2>
            <p className="p">
              Every year, millions of tons of edible food are wasted,
              contributing to environmental issues and hunger problems. By
              connecting excess food with those in need, we can reduce waste and
              feed more people.
            </p>
          </Col>
        </Row>
        
        <Container className="d-flex  justify-content-center carousel">
          <Row>
            <Col>
              <LandingCarousel />
            </Col>
          </Row>
        </Container>
       
        <Row>
          <Col>
            <h2 className="subheadings">Our Mission</h2>
            <p className="p">
              ResQFood aims to reduce food wastage by connecting donors with
              recipients through an easy-to-use platform. Together, we can make
              a difference, one meal at a time.
            </p>
          </Col>
        </Row>
        <Row>
          <Col>
            <h2 className="subheadings">Get Involved</h2>
            <p className="p">
              You can help by donating excess food from events like weddings and
              engagements. By notifying us early, we can ensure that no food
              goes to waste.
            </p>
          </Col>
        </Row>
      </Container>


      <footer
        className="p-0 m-0 footer" style={{background:'rgba(0,0,0,0.6)',color:'rgba(255,255,222,0.8)'}}>
        <div className="container-fluid" style={{textAlign:'start',fontSize:'medium'}}>
          <div className="row">
            <div className="col m-0 px-5 pt-3">
              <h5>About Us</h5>
              <p>
                ResQFood aims to reduce food wastage by connecting donors with
                recipients through an easy-to-use platform. Together, we can
                make a difference, one meal at a time.
              </p>
              <div className="col">
                <ul className="footer-social">
                  <div className="pb-1 mb-1 container social-account-container">
                    <div className="d-flex justify-content-center social-accounts">
                      <button className="social-button google">
                        <svg
                          className="svg"
                          xmlns="http://www.w3.org/2000/svg"
                          height="0.7em"
                          viewBox="0 0 488 512">
                          <path d="M488 261.8C488 403.3 391.1 504 248 504 110.8 504 0 393.2 0 256S110.8 8 248 8c66.8 0 123 24.5 166.3 64.9l-67.5 64.9C258.5 52.6 94.3 116.6 94.3 256c0 86.5 69.1 156.6 153.7 156.6 98.2 0 135-70.4 140.8-106.9H248v-85.3h236.1c2.3 12.7 3.9 24.9 3.9 41.4z"></path>
                        </svg>
                      </button>
                      <button className="social-button apple">
                        <svg
                          className="svg"
                          xmlns="http://www.w3.org/2000/svg"
                          height="0.7em"
                          viewBox="0 0 384 512">
                          <path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z"></path>
                        </svg>
                      </button>
                      <button className="social-button twitter">
                        <svg
                          className="svg"
                          xmlns="http://www.w3.org/2000/svg"
                          height="0.7em"
                          viewBox="0 0 512 512">
                          <path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"></path>
                        </svg>
                      </button>
                    </div>
                  </div>
                </ul>
              </div>
            </div>

            <div className="col-md-3 px-2 pt-3">
              <h5>Contact Us</h5>
              <p>123 Kottayam, Kerala, India</p>
              <p>Email: resqfood2224@gmail.com</p>
              <p>Phone: +1234567890</p>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <div className="container pb-1">
            <div className="row">
              <div className="col">
                <p>&copy; 2024 Your Company. All Rights Reserved.</p>
              </div>
          
            </div>
          </div>
        </div>
      </footer>

    </Container>
  );
};

export default LandingPage;
